package com.example.charles.assembly;

import android.widget.EditText;

public class createEvents {
    EditText eventText;


}
